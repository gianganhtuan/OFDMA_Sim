# OFDMA-Sim
A simple IEEE 802.11ax OFDMA downlink scheduler simulator

To compile the simulator:
g++ *.cpp -o ./sim

To verify with some test scenarios:
g++ test.cpp -o ./test
